import { useState, useEffect } from 'react';
import { io, Socket } from 'socket.io-client';

let socket: Socket | null = null;

export const useSocket = () => {
  const [connected, setConnected] = useState(false);
  const [playerId] = useState(() => {
    const saved = sessionStorage.getItem('funish_player_id');
    if (saved) return saved;
    const newId = Math.random().toString(36).substring(2, 15);
    sessionStorage.setItem('funish_player_id', newId);
    return newId;
  });

  useEffect(() => {
    if (!socket) {
      socket = io();
    }

    const onConnect = () => {
      console.log('Socket connected:', socket?.id);
      setConnected(true);
    };
    const onDisconnect = () => setConnected(false);

    socket.on('connect', onConnect);
    socket.on('disconnect', onDisconnect);

    if (socket.connected) onConnect();

    return () => {
      socket?.off('connect', onConnect);
      socket?.off('disconnect', onDisconnect);
    };
  }, []);

  return { socket, connected, playerId };
};
